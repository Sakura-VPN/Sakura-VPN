/**
 * OPEN60 VPN — Production Popup
 * Сохраняем старый UI/UX, адаптируем к новому API
 */

// Production API
const API_BASE = "https://api.open60m.ru";

console.log(`🌐 API Base: ${API_BASE}`);

/* =======================
   FETCH (с обработкой ошибок)
======================= */
async function apiFetch(url, options = {}) {
  try {
    const response = await fetch(url, { ...options, cache: "no-store" });
    return response;
  } catch (error) {
    console.error("Fetch error:", error);
    throw new Error("Network error");
  }
}

async function apiJson(url, options = {}) {
  const response = await apiFetch(url, options);
  
  if (!response.ok) {
    const text = await response.text().catch(() => "Unknown error");
    console.error(`API error ${response.status}:`, text.substring(0, 200));
    throw new Error(`Server error: ${response.status}`);
  }
  
  const contentType = response.headers.get("content-type");
  if (!contentType || !contentType.includes("application/json")) {
    const text = await response.text().catch(() => "");
    console.error("Non-JSON response:", text.substring(0, 200));
    console.error("Content-Type:", contentType);
    throw new Error("Server returned HTML instead of JSON");
  }
  
  return response.json();
}

/* =======================
   ELEMENTS
======================= */
const toggleBtn = document.getElementById("toggleBtn");
const btnTitle = document.getElementById("btnTitle");
const btnSub = document.getElementById("btnSub");
const headerStatus = document.getElementById("headerStatus");
const dot = document.getElementById("dot");
const servers = Array.from(document.querySelectorAll(".server"));

const autoTimerBox = document.getElementById("autoTimer");
const autoTimerValue = document.getElementById("autoTimerValue");
const freeInfoBox = document.getElementById("freeInfo");

const premiumBox = document.getElementById("premiumBox");
const buyPremiumBtn = document.getElementById("buyPremiumBtn");

/* =======================
   CONSTANTS / STATE
======================= */
const AUTO_DISABLE_MS = 30 * 60 * 1000;
const CONNECT_DELAY_MS = 400;  // v3.0: Reduced from 1200ms (Hot Pool is fast!)
let timer = null;
let updateQueued = false;
let uiLockedUntil = 0;



/* =======================
   UI LOCK
======================= */
function lockUI(ms) {
  uiLockedUntil = Date.now() + ms;
}

function isLocked() {
  return Date.now() < uiLockedUntil;
}

/* =======================
   BACKGROUND HELPERS
======================= */
function bgMessage(payload) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(payload, (resp) => {
      if (chrome.runtime.lastError) {
        console.warn("bgMessage error:", chrome.runtime.lastError);
        resolve({ ok: false });
      } else {
        resolve(resp || { ok: false });
      }
    });
  });
}

async function getInstallIdFromBg() {
  const r = await bgMessage({ type: "GET_INSTALL_ID" });
  return r.install_id || null;
}

/* =======================
   TOAST NOTIFICATIONS
======================= */
function showToast(message, type = "info") {
  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  toast.textContent = message;
  
  document.body.appendChild(toast);
  
  setTimeout(() => {
    toast.style.animation = "slideUp 0.3s ease reverse";
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

/* =======================
   TIMER (free)
======================= */
function formatLeft(ms) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const m = String(Math.floor(total / 60)).padStart(2, "0");
  const s = String(total % 60).padStart(2, "0");
  return `${m}:${s}`;
}

function startTimer(startedAt) {
  stopTimer();
  if (!autoTimerBox || !autoTimerValue) return;
  
  autoTimerBox.hidden = false;
  if (freeInfoBox) freeInfoBox.hidden = false;

  const tick = async () => {
    const left = AUTO_DISABLE_MS - (Date.now() - startedAt);
    if (left <= 0) {
      stopTimer();
      // Отправляем команду отключения VPN в background
      console.log("[Popup] Timer expired, disabling VPN");
      await bgMessage("VPN_DISABLE");
      setButton("off");
      setHeader("off", "");
      setTimeout(init, 500);
      return;
    }
    autoTimerValue.textContent = formatLeft(left);
  };

  tick();
  timer = setInterval(tick, 1000);
}

function stopTimer() {
  if (timer) clearInterval(timer);
  timer = null;
  if (autoTimerBox) autoTimerBox.hidden = true;
  if (freeInfoBox) freeInfoBox.hidden = true;
}

/* =======================
   UI HELPERS
======================= */
function getServerMeta(serverKey) {
  const el = servers.find(s => s.dataset.server === serverKey);
  return { name: el?.dataset.name || "серверу", city: el?.dataset.city || "" };
}

function markActiveServer(serverKey) {
  servers.forEach(s =>
    s.classList.toggle("active", s.dataset.server === serverKey)
  );
}

function setHeader(mode, serverName, direction = "connect") {
  if (mode === "loading") {
    dot.style.background = "#f5a623";
    headerStatus.textContent = direction === "disconnect" ? "Отключаемся…" : "Устанавливаем соединение…";
    headerStatus.style.color = "#f5a623";
    return;
  }
  if (mode === "on") {
    dot.style.background = "#2ecc71";
    headerStatus.textContent = `Подключен к ${serverName}`;
    headerStatus.style.color = "#2ecc71";
    return;
  }
  dot.style.background = "#bbb";
  headerStatus.textContent = "Отключено";
  headerStatus.style.color = "#888";
}

function setButton(mode, premium = false, direction = "connect") {
  toggleBtn.classList.remove("on", "off", "loading");
  toggleBtn.classList.add(mode);

  if (mode === "loading") {
    if (direction === "disconnect") {
      btnTitle.textContent = "Отключение…";
      btnSub.textContent = "Завершаем сессию";
    } else {
      btnTitle.textContent = "Подключение…";
      btnSub.textContent = "Устанавливаем соединение";
    }
    return;
  }

  if (mode === "on") {
    btnTitle.textContent = "Отключиться";
    btnSub.textContent = "VPN работает";
    return;
  }

  btnTitle.textContent = "Подключиться";
  btnSub.textContent = "Вы не защищены";
}

/* =======================
   INIT
======================= */
function init() {
  if (updateQueued) return;
  updateQueued = true;

  chrome.storage.local.get(
    ["enabled", "server", "vpnStartedAt", "premiumStatus", "premiumUntil", "vpn_state"],
    (d) => {
      updateQueued = false;

      const enabled = !!d.enabled;
      const serverKey = d.server || "de";
      const premium = d.premiumStatus === true;
      const premiumUntil = d.premiumUntil || null;
      const vpnState = d.vpn_state || "OFF";
      const meta = getServerMeta(serverKey);
      const isTransitioning = ["ENABLING", "DISABLING", "SWITCHING"].includes(vpnState);

      markActiveServer(serverKey);
      updatePremiumLockedServers(premium);

      if (isTransitioning) {
        const isDisconnecting = vpnState === "DISABLING";
        setButton("loading", false, isDisconnecting ? "disconnect" : "connect");
        setHeader("loading", meta.name, isDisconnecting ? "disconnect" : "connect");
        stopTimer();
      } else {
        setButton(enabled ? "on" : "off", premium);
        setHeader(enabled ? "on" : "off", meta.name);
        if (enabled && !premium && d.vpnStartedAt && vpnState === "ON") {
          startTimer(d.vpnStartedAt);
        } else {
          stopTimer();
        }
      }

      updatePremiumButton(premium, premiumUntil);
      if (premiumBox) premiumBox.hidden = false;
    }
  );
}

/* =======================
   LISTENER для обновлений от background
======================= */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "POPUP_UPDATE") {
    console.log("[Popup] Background update:", msg);

    if (msg.state === "ON") {
      chrome.storage.local.get(["server", "premiumStatus", "vpnStartedAt"], (d) => {
        const premium = d.premiumStatus === true;
        const meta = getServerMeta(d.server || "de");
        setButton("on", premium);
        setHeader("on", meta.name);
        if (msg.switched) {
          showToast(`Подключено к ${meta.name}`, "success");
        }
        if (!premium && d.vpnStartedAt) {
          startTimer(d.vpnStartedAt);
        }
      });
    }

    if (msg.state === "ENABLING" || msg.state === "SWITCHING") {
      chrome.storage.local.get(["server"], (d) => {
        const meta = getServerMeta(d.server || "de");
        setButton("loading");
        setHeader("loading", meta.name);
        stopTimer();
      });
    }

    if (msg.state === "DISABLING") {
      chrome.storage.local.get(["server"], (d) => {
        const meta = getServerMeta(d.server || "de");
        setButton("loading", false, "disconnect");
        setHeader("loading", meta.name, "disconnect");
        stopTimer();
      });
    }

    if (msg.state === "OFF") {
      chrome.storage.local.get(["server"], (d) => {
        const meta = getServerMeta(d.server || "de");
        setButton("off");
        setHeader("off", meta.name);
        stopTimer();
      });
    }

    if (msg.type === "STATE_ERROR" || msg.error) {
      setButton("off");
      chrome.storage.local.get(["server"], (d) => {
        setHeader("off", getServerMeta(d.server || "de").name);
      });
      showToast(msg.error || "Ошибка подключения", "error");
    }

    sendResponse({ ok: true });
    return true;
  }
});

/* =======================
   MAIN BUTTON
======================= */
toggleBtn.addEventListener("click", () => {
  if (isLocked()) return;

  chrome.storage.local.get(["enabled", "server"], async (data) => {
    const enabled = Boolean(data.enabled);
    const serverKey = data.server || "de";
    const meta = getServerMeta(serverKey);

    if (enabled) {
      setButton("loading", false, "disconnect");
      setHeader("loading", meta.name, "disconnect");
      stopTimer();
      await bgMessage("VPN_DISABLE");
      // UI reset will come via POPUP_UPDATE STATE_CHANGE "OFF" from background
      return;
    }

    setButton("loading");
    setHeader("loading", meta.name);
    lockUI(CONNECT_DELAY_MS + 100);

    await bgMessage("VPN_ENABLE");
    // UI is now driven by POPUP_UPDATE from background (STATE_CHANGE / STATE_ERROR).
    // No setTimeout needed — if background succeeds it sends STATE_CHANGE "ON",
    // if it fails it sends STATE_ERROR and we reset the button there.
  });
});

function updatePremiumLockedServers(premium) {
  servers.forEach(s => {
    if (s.dataset.premiumOnly === "true") {
      if (premium) {
        s.classList.add("unlocked");
        // Replace lock icon with dot indicator
        const lockEl = s.querySelector(".server-lock-icon");
        if (lockEl) lockEl.style.display = "none";
        let dot = s.querySelector(".server-dot");
        if (!dot) {
          dot = document.createElement("div");
          dot.className = "server-dot";
          s.appendChild(dot);
        }
        dot.style.display = "";
        // Remove premium tag once unlocked
        const tag = s.querySelector(".premium-tag");
        if (tag) tag.style.display = "none";
      } else {
        s.classList.remove("unlocked");
      }
    }
  });
}

/* =======================
   PREMIUM SERVER LOCK CLICK
======================= */
/* =======================
   SERVER CLICK
======================= */
servers.forEach((s) => {
  s.addEventListener("click", async () => {
    if (isLocked()) return;

    const serverKey = s.dataset.server;
    const isPremiumOnly = s.dataset.premiumOnly === "true";

    const isCurrentlyActive = s.classList.contains("active");
    if (isCurrentlyActive) return;

    const meta = getServerMeta(serverKey);
    const isEnabled = toggleBtn.classList.contains("on");

    markActiveServer(serverKey);

    if (isEnabled) {
      s.classList.add("loading");
      setButton("loading");
      setHeader("loading", meta.name);
      lockUI(3000);

      await bgMessage({ type: "SET_SERVER", server: serverKey });

      s.classList.remove("loading");
      // UI обновится через POPUP_UPDATE STATE_CHANGE "ON" от background
    } else {
      await bgMessage({ type: "SET_SERVER", server: serverKey });
    }
  });
});


/* =======================
   STORAGE LISTENER
======================= */
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;

  const newVpnState = changes.vpn_state?.newValue;

  if (newVpnState === "ENABLING" || newVpnState === "DISABLING" || newVpnState === "SWITCHING") {
    return;
  }

  if (newVpnState === "ON" || newVpnState === "OFF") {
    console.log("[Popup] VPN state finalized:", newVpnState);
    init();
    return;
  }

  if (isLocked()) return;

  if (changes.enabled || changes.premiumStatus || changes.server) {
    console.log("[Popup] Storage changed, updating UI");
    init();
  }
});

/* =======================
   START
======================= */
init();
checkPremiumOnOpen();