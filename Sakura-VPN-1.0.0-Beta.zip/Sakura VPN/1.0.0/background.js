// ========= CONFIGURATION =========
const CONFIG = {
  API_BASE: "https://api.open60m.ru",
  API_FALLBACK: "https://api2.open60m.ru",

  // Refresh tokens before expiry (5 minutes)
  REFRESH_BEFORE_EXPIRY_MS: 5 * 60 * 1000,
  
  // Check session every 2 minutes using ALARMS (survives service worker sleep!)
  SESSION_CHECK_ALARM: "session-check",
  SESSION_CHECK_INTERVAL_MINUTES: 2,
  
  // Auto-disable for free users (30 minutes)
  AUTO_DISABLE_MS: 30 * 60 * 1000,
  AUTO_DISABLE_ALARM: "vpn-auto-disable",
  
  // State sync alarm (check every 30 seconds if state is synced)
  STATE_SYNC_ALARM: "state-sync-check",
  STATE_SYNC_INTERVAL_MINUTES: 0.5, // 30 seconds
  
  // Retry settings
  MAX_RETRIES: 3,
  RETRY_DELAY_MS: 1000
};

// ========= STORAGE KEYS =========
// Все критические данные теперь в storage, а не в памяти!
const STORAGE_KEYS = {
  INSTALL_ID: "install_id",
  SESSION: "vpn_session",
  VPN_STATE: "vpn_state",
  ENABLED: "enabled",
  SERVER: "server",
  STARTED_AT: "vpnStartedAt",
  PREMIUM_STATUS: "premiumStatus",
  PREMIUM_UNTIL: "premiumUntil",
  PREMIUM_CHECKED_AT: "premiumCheckedAt",
  OPERATION_IN_PROGRESS: "operationInProgress",
  LAST_STATE_SYNC: "lastStateSync"
};

// ========= STORAGE HELPERS =========
function storageGet(keys) {
  return new Promise((resolve) => {
    chrome.storage.local.get(keys, resolve);
  });
}

function storageSet(data) {
  return new Promise((resolve) => {
    chrome.storage.local.set(data, resolve);
  });
}

function storageRemove(keys) {
  return new Promise((resolve) => {
    chrome.storage.local.remove(keys, resolve);
  });
}

// ========= INSTALL ID =========
async function getOrCreateInstallId() {
  const local = await storageGet(STORAGE_KEYS.INSTALL_ID);
  if (local[STORAGE_KEYS.INSTALL_ID]) {
    console.log("✅ Loaded install_id:", local[STORAGE_KEYS.INSTALL_ID]);
    return local[STORAGE_KEYS.INSTALL_ID];
  }

  const installId = crypto.randomUUID();
  console.log("✅ Generated install_id:", installId);
  await storageSet({ [STORAGE_KEYS.INSTALL_ID]: installId });
  return installId;
}

// ========= API HELPERS =========
function apiFetch(url, options = {}) {
  return fetch(url, { ...options, cache: "no-store" });
}

function fetchWithTimeout(url, options = {}, timeout = 10000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  return fetch(url, { ...options, signal: controller.signal })
    .finally(() => clearTimeout(timer));
}

async function apiRequest(endpoint, options = {}, retries = CONFIG.MAX_RETRIES) {
  const defaultOptions = {
    headers: {
      "Content-Type": "application/json"
    },
    mode: 'cors',
    credentials: 'omit'
  };

  const mergedOptions = {
    ...defaultOptions,
    ...options,
    headers: {
      ...defaultOptions.headers,
      ...options.headers
    }
  };

  const bases = [CONFIG.API_BASE, CONFIG.API_FALLBACK];
  let lastError;

  for (const base of bases) {
    const url = `${base}${endpoint}`;
    const isPrimary = base === CONFIG.API_BASE;

    // Основной: 1 попытка, 3 сек — быстро понять что недоступен
    // Fallback: полные retries, 7 сек — надёжно достучаться
    const maxAttempts = isPrimary ? 1 : retries;
    const timeout = isPrimary ? 3000 : 7000;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        console.log(`[QU] API ${options.method || "GET"} ${url} (attempt ${attempt})`);

        const response = await fetchWithTimeout(url, mergedOptions, timeout);

        // Check if response is JSON
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
          console.error(`[QU] Non-JSON response from server. Content-Type: ${contentType}`);
          throw new Error('Server returned non-JSON response');
        }

        const data = await response.json();

        if (!response.ok) {
          console.error(`[QU] API error: ${response.status}`, data);

          if (response.status === 401 || response.status === 403) {
            throw new Error(data.error || data.message || "Unauthorized");
          }

          if (response.status === 429) {
            const retryAfter = data.retry_after || 60;
            throw new Error(`rate_limit:${retryAfter}`);
          }

          throw new Error(data.error || data.message || `HTTP ${response.status}`);
        }

        if (!isPrimary) {
          console.log(`[QU] ✅ Connected via fallback: ${base}`);
        }

        return data;

      } catch (error) {
        lastError = error;
        console.error(`[QU] ${url} failed (attempt ${attempt}):`, error.message);

        // Эти ошибки — не сетевые, fallback не поможет
        if (error.message.startsWith("rate_limit:") ||
            error.message === "Unauthorized" ||
            error.message === "token_expired" ||
            error.message === "token_invalid") {
          throw error;
        }

        if (attempt < maxAttempts) {
          const delay = CONFIG.RETRY_DELAY_MS * Math.pow(2, attempt - 1);
          const jitter = Math.random() * 300;
          await new Promise(resolve => setTimeout(resolve, delay + jitter));
        }
      }
    }

    console.warn(`[QU] ⚠️ ${isPrimary ? "Primary" : "Fallback"} API unavailable, ${isPrimary ? "switching to fallback..." : "giving up."}`);
  }

  throw lastError || new Error("All API endpoints unavailable");
}

// ========= PROXY MANAGEMENT =========
async function setProxy(host, port) {
  return new Promise((resolve, reject) => {
    chrome.proxy.settings.set(
      {
        value: {
          mode: "fixed_servers",
          rules: {
            singleProxy: {
              scheme: "http",
              host: host,
              port: port
            },
            bypassList: ["<local>"]
          }
        },
        scope: "regular"
      },
      () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          console.log(`[QU] Proxy set to ${host}:${port}`);
          resolve();
        }
      }
    );
  });
}

async function clearProxy() {
  return new Promise((resolve, reject) => {
    chrome.proxy.settings.clear({ scope: "regular" }, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        console.log("[QU] Proxy cleared");
        resolve();
      }
    });
  });
}

async function isProxyActuallyActive() {
  return new Promise((resolve) => {
    chrome.proxy.settings.get({ incognito: false }, (config) => {
      const isActive = config?.value?.mode === "fixed_servers";
      resolve(isActive);
    });
  });
}

async function getCurrentProxyConfig() {
  return new Promise((resolve) => {
    chrome.proxy.settings.get({ incognito: false }, (config) => {
      resolve(config?.value);
    });
  });
}

// ========= SESSION MANAGEMENT =========
async function saveSession(session) {
  await storageSet({ [STORAGE_KEYS.SESSION]: session });
  console.log("[QU] Session saved to storage");
}

async function loadSession() {
  const result = await storageGet(STORAGE_KEYS.SESSION);
  return result[STORAGE_KEYS.SESSION] || null;
}

async function clearSession() {
  await storageRemove(STORAGE_KEYS.SESSION);
  console.log("[QU] Session cleared from storage");
}

function isSessionExpiringSoon(session) {
  if (!session || !session.expires_at) return true;
  
  const expiresAt = new Date(session.expires_at).getTime();
  const now = Date.now();
  
  return (expiresAt - now) < CONFIG.REFRESH_BEFORE_EXPIRY_MS;
}

// ========= VPN STATE MANAGEMENT =========
async function getVpnState() {
  const result = await storageGet(STORAGE_KEYS.VPN_STATE);
  return result[STORAGE_KEYS.VPN_STATE] || "OFF";
}

async function setVpnState(state) {
  await storageSet({ [STORAGE_KEYS.VPN_STATE]: state });
  console.log(`[QU] VPN state set to: ${state}`);
}

// ========= OPERATION LOCK =========
async function isOperationInProgress() {
  const result = await storageGet(STORAGE_KEYS.OPERATION_IN_PROGRESS);
  const lockData = result[STORAGE_KEYS.OPERATION_IN_PROGRESS];
  
  if (!lockData) return false;
  
  // Lock expires after 30 seconds (prevents deadlock if something crashes)
  if (Date.now() - lockData.timestamp > 30000) {
    await storageRemove(STORAGE_KEYS.OPERATION_IN_PROGRESS);
    return false;
  }
  
  return true;
}

async function setOperationLock(operation) {
  await storageSet({
    [STORAGE_KEYS.OPERATION_IN_PROGRESS]: {
      operation,
      timestamp: Date.now()
    }
  });
}

async function clearOperationLock() {
  await storageRemove(STORAGE_KEYS.OPERATION_IN_PROGRESS);
}

// ========= PREMIUM STATUS =========
async function fetchPremiumStatus(force = false) {
  const id = await getOrCreateInstallId();

  if (!force) {
    const d = await storageGet([
      STORAGE_KEYS.PREMIUM_STATUS, 
      STORAGE_KEYS.PREMIUM_CHECKED_AT, 
      STORAGE_KEYS.PREMIUM_UNTIL
    ]);
    
    if (d[STORAGE_KEYS.PREMIUM_STATUS] !== undefined && 
        d[STORAGE_KEYS.PREMIUM_CHECKED_AT] && 
        Date.now() - d[STORAGE_KEYS.PREMIUM_CHECKED_AT] < 5 * 60 * 1000) {
      return { 
        premium: d[STORAGE_KEYS.PREMIUM_STATUS], 
        premium_until: d[STORAGE_KEYS.PREMIUM_UNTIL],
        cached: true 
      };
    }
  }

  try {
    const data = await apiRequest(`/premium/status?install_id=${encodeURIComponent(id)}`);
    const premium = data?.premium === true;
    const premiumUntil = data?.premium_until || null;

    await storageSet({
      [STORAGE_KEYS.PREMIUM_STATUS]: premium,
      [STORAGE_KEYS.PREMIUM_UNTIL]: premiumUntil,
      [STORAGE_KEYS.PREMIUM_CHECKED_AT]: Date.now()
    });

    return { premium, premium_until: premiumUntil, cached: false };
  } catch (e) {
    console.warn("[QU] premium check failed:", e);
    // BUGFIX: On network error, fall back to cached value instead of returning false.
    // Previously this would reset premium users to free tier if API was briefly unavailable,
    // causing the 30-min auto-disable timer to start for premium users.
    const cached = await storageGet([STORAGE_KEYS.PREMIUM_STATUS, STORAGE_KEYS.PREMIUM_UNTIL]);
    const cachedPremium = cached[STORAGE_KEYS.PREMIUM_STATUS];
    if (cachedPremium !== undefined) {
      console.warn("[QU] Using cached premium status due to API error:", cachedPremium);
      return { premium: cachedPremium, premium_until: cached[STORAGE_KEYS.PREMIUM_UNTIL] || null, error: e.message, cached: true };
    }
    return { premium: false, premium_until: null, error: e.message };
  }
}

// ========= TIMER (для бесплатных пользователей) =========
function startAutoDisable(startedAt) {
  chrome.alarms.clear(CONFIG.AUTO_DISABLE_ALARM, () => {
    chrome.alarms.create(CONFIG.AUTO_DISABLE_ALARM, {
      when: startedAt + CONFIG.AUTO_DISABLE_MS
    });
    console.log("[QU] Auto-disable alarm set");
  });
}

function clearAutoDisable() {
  chrome.alarms.clear(CONFIG.AUTO_DISABLE_ALARM, () => {
    console.log("[QU] Auto-disable alarm cleared");
  });
}

// ========= SESSION CHECK ALARM =========
function startSessionCheckAlarm() {
  chrome.alarms.clear(CONFIG.SESSION_CHECK_ALARM, () => {
    chrome.alarms.create(CONFIG.SESSION_CHECK_ALARM, {
      periodInMinutes: CONFIG.SESSION_CHECK_INTERVAL_MINUTES
    });
    console.log("[QU] Session check alarm started (every 2 minutes)");
  });
}

function stopSessionCheckAlarm() {
  chrome.alarms.clear(CONFIG.SESSION_CHECK_ALARM, () => {
    console.log("[QU] Session check alarm stopped");
  });
}

// ========= STATE SYNC CHECK ALARM =========
function startStateSyncAlarm() {
  chrome.alarms.clear(CONFIG.STATE_SYNC_ALARM, () => {
    chrome.alarms.create(CONFIG.STATE_SYNC_ALARM, {
      periodInMinutes: CONFIG.STATE_SYNC_INTERVAL_MINUTES
    });
    console.log("[QU] State sync alarm started (every 30 seconds)");
  });
}

function stopStateSyncAlarm() {
  chrome.alarms.clear(CONFIG.STATE_SYNC_ALARM);
}

// ========= NOTIFICATIONS =========
function notifyPopup(data) {
  chrome.runtime.sendMessage({ type: "POPUP_UPDATE", ...data }).catch(() => {
    // Popup может быть закрыт
  });
}

// ========= VPN EXTENSIONS CHECK =========
async function checkOtherVPNExtensions() {
  try {
    const allExtensions = await chrome.management.getAll();
    const currentExtensionId = chrome.runtime.id;
    
    const conflictingExtensions = allExtensions.filter(ext => {
      if (ext.id === currentExtensionId) return false;
      if (ext.enabled === false) return false;
      
      const permissions = ext.permissions || [];
      const hasProxyPermission = permissions.includes("proxy") || 
                                  permissions.some(p => p.toLowerCase().includes("proxy"));
      
      const name = (ext.name || "").toLowerCase();
      const desc = (ext.description || "").toLowerCase();
      const keywords = ["vpn", "прокси", "proxy"];
      const hasVPNKeywords = keywords.some(keyword => 
        name.includes(keyword) || desc.includes(keyword)
      );
      
      return hasProxyPermission || hasVPNKeywords;
    });
    
    return conflictingExtensions;
  } catch (error) {
    console.error("[QU] Error checking extensions:", error);
    return [];
  }
}

async function disableOtherVPNExtensions(conflictingExtensions) {
  const toDisable = conflictingExtensions || await checkOtherVPNExtensions();
  const disabledNames = [];

  for (const ext of toDisable) {
    try {
      await chrome.management.setEnabled(ext.id, false);
      disabledNames.push(ext.name);
      console.log(`[QU] Disabled extension: ${ext.name}`);
    } catch (error) {
      console.error(`[QU] Failed to disable ${ext.name}:`, error);
    }
  }

  return disabledNames;
}

// ========= SERVERS DEFINITION =========
const SERVERS = {
  de: { name: "Германия", code: "DE" },
  nl: { name: "Нидерланды", code: "NL" },
  ru: { name: "Россия", code: "RU" }
};

function getServerByKey(key) {
  return SERVERS[key];
}

function getServerName(key) {
  return SERVERS[key]?.name || key;
}

// ========= CORE SESSION FUNCTIONS =========

/**
 * Create new VPN session
 */
async function createSession(serverKey = "de") {
  const installId = await getOrCreateInstallId();
  
  // Map serverKey to country code
  const server = SERVERS[serverKey];
  if (!server) {
    throw new Error(`Invalid server key: ${serverKey}`);
  }
  
  const countryCode = server.code; // "DE" or "NL"
  
  console.log(`[QU] Creating session for server: ${serverKey} (${countryCode})`);
  
  const data = await apiRequest("/session/create", {
    method: "POST",
    body: JSON.stringify({
      install_id: installId,
      country: countryCode
    })
  });
  
  const session = {
    session_id: data.session_id,
    access_token: data.access_token,
    refresh_token: data.refresh_token,
    expires_at: data.expires_at,
    proxy: {
      host: data.proxy.host,
      port: data.proxy.port
    },
    country: countryCode,
    serverKey: serverKey,
    connected_at: new Date().toISOString()
  };
  
  await saveSession(session);
  
  console.log(`[QU] Session created: ${session.session_id.substring(0, 16)}...`);
  console.log(`[QU] Proxy: ${session.proxy.host}:${session.proxy.port}`);
  
  return session;
}

/**
 * v2.5: Refresh session with migration support
 * 
 * Checks /session/status for migration object
 * If migration available → switches to new session seamlessly
 */
async function refreshSession() {
  const currentSession = await loadSession();
  
  if (!currentSession || !currentSession.access_token) {
    console.log("[QU] No session to refresh");
    return null;
  }
  
  console.log("[QU] Checking session status (migration check)...");
  
  try {
    const data = await apiRequest("/session/status", {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${currentSession.access_token}`
      }
    });
    
    // v2.5: Check for migration
    if (data.migration) {
      console.log("[QU] 🔄 Migration available! Switching to new session...");
      
      const migration = data.migration;
      
      // Switch to new proxy
      console.log(`[QU] Switching proxy: ${migration.new_host}:${migration.new_port}`);
      await setProxy(migration.new_host, migration.new_port);
      
      // Update session with new data
      const newSession = {
        session_id: migration.new_session_id,
        access_token: migration.new_access_token,
        refresh_token: migration.new_refresh_token,
        expires_at: migration.new_expires_at,
        proxy: {
          host: migration.new_host,
          port: migration.new_port
        },
        country: currentSession.country,  // Keep same country
        serverKey: currentSession.serverKey,  // Keep same server key
        connected_at: new Date().toISOString()
      };
      
      await saveSession(newSession);
      
      console.log(`[QU] ✅ Migration completed silently!`);
      console.log(`[QU] New session: ${newSession.session_id.substring(0, 16)}...`);
      console.log(`[QU] New proxy: ${newSession.proxy.host}:${newSession.proxy.port}`);
      
      // Old session will expire naturally (no need to destroy)
      return newSession;
    }
    
    // No migration needed, just return current session
    console.log("[QU] Session status OK, no migration needed");
    return currentSession;
    
  } catch (error) {
    console.error("[QU] Session check failed:", error.message);
    
    if (error.message === "token_expired" || 
        error.message === "token_invalid" || 
        error.message === "session_invalid" ||
        error.message === "session_not_found") {
      console.log("[QU] Session expired or invalid, disabling VPN");
      await doDisable(false);
    }
    
    throw error;
  }
}

/**
 * v2.3: Destroy session (instant port close on server)
 */
async function destroySession() {
  const currentSession = await loadSession();
  
  if (!currentSession || !currentSession.access_token) {
    console.log("[QU] No session to destroy");
    return;
  }
  
  console.log("[QU] Destroying session...");
  
  try {
    // Без retry — fire-and-forget, сессия умрёт по TTL если запрос не дойдёт
    await apiRequest("/session/destroy", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${currentSession.access_token}`
      }
    }, 1);
    console.log("[QU] Session destroyed on server (port closed)");
  } catch (error) {
    console.warn("[QU] destroySession failed (will expire by TTL):", error.message);
  }
}

// ========= STATE SYNCHRONIZATION =========

/**
 * КРИТИЧЕСКАЯ ФУНКЦИЯ: Проверяет синхронизацию состояния
 * Вызывается каждые 30 секунд через alarm
 */
async function checkStateSync() {
  const state = await storageGet([
    STORAGE_KEYS.ENABLED,
    STORAGE_KEYS.SESSION,
    STORAGE_KEYS.VPN_STATE
  ]);
  
  const shouldBeEnabled = state[STORAGE_KEYS.ENABLED] === true;
  const hasSession = !!state[STORAGE_KEYS.SESSION];
  const vpnState = state[STORAGE_KEYS.VPN_STATE] || "OFF";
  const proxyActive = await isProxyActuallyActive();
  
  console.log(`[QU] State sync check: enabled=${shouldBeEnabled}, hasSession=${hasSession}, vpnState=${vpnState}, proxyActive=${proxyActive}`);
  
  // Случай 1: Должен быть включен, есть сессия, но прокси не активен
  if (shouldBeEnabled && hasSession && !proxyActive && vpnState !== "DISABLING") {
    console.warn("[QU] ⚠️ Desync detected: VPN should be ON but proxy is OFF. Reconnecting...");
    
    const session = state[STORAGE_KEYS.SESSION];
    try {
      await setProxy(session.proxy.host, session.proxy.port);
      await setVpnState("ON");
      console.log("[QU] ✅ Proxy reconnected successfully");
    } catch (error) {
      console.error("[QU] Failed to reconnect proxy:", error);
      // Если не удалось восстановить прокси, отключаем VPN
      await doDisable(false);
    }
    return;
  }
  
  // Случай 2: Не должен быть включен, но прокси активен
  if (!shouldBeEnabled && proxyActive && vpnState !== "ENABLING") {
    console.warn("[QU] ⚠️ Desync detected: VPN should be OFF but proxy is ON. Clearing...");
    
    try {
      await clearProxy();
      await setVpnState("OFF");
      console.log("[QU] ✅ Proxy cleared successfully");
    } catch (error) {
      console.error("[QU] Failed to clear proxy:", error);
    }
    return;
  }
  
  // Случай 3: Включен, но нет сессии (критическая ошибка)
  if (shouldBeEnabled && !hasSession && proxyActive) {
    console.error("[QU] ⚠️ Critical desync: VPN enabled but no session. Force disable...");
    await doDisable(false);
    return;
  }
  
  // Обновляем timestamp последней проверки
  await storageSet({ [STORAGE_KEYS.LAST_STATE_SYNC]: Date.now() });
}

// ========= MAIN ACTIONS =========

async function doEnable() {
  // Защита от race condition
  if (await isOperationInProgress()) {
    console.log("[QU] Operation already in progress, skipping");
    return;
  }
  
  await setOperationLock("ENABLE");

  try {
    await setVpnState("ENABLING");
    notifyPopup({ type: "STATE_CHANGE", state: "ENABLING" });

    // Получаем текущий сервер из storage
    const storageData = await storageGet(STORAGE_KEYS.SERVER);
    const currentServerKey = storageData[STORAGE_KEYS.SERVER] || "de";

    // Все три операции параллельно — premium, сессия и поиск конфликтов
    const [{ premium }, session, conflicting] = await Promise.all([
      fetchPremiumStatus(false),
      createSession(currentServerKey),
      checkOtherVPNExtensions()
    ]);

    // Отключаем конфликтующие расширения прямо перед setProxy
    if (conflicting.length > 0) {
      console.log(`[QU] Found ${conflicting.length} conflicting extensions`);
      const disabled = await disableOtherVPNExtensions(conflicting);
      if (disabled.length > 0) {
        chrome.notifications.create({
          type: "basic",
          iconUrl: "icon.png",
          title: "Sakura VPN",
          message: `Отключены конфликтующие расширения: ${disabled.join(", ")}`
        });
      }
    }

    await setProxy(session.proxy.host, session.proxy.port);

    const startedAt = Date.now();

    await storageSet({
      [STORAGE_KEYS.ENABLED]: true,
      [STORAGE_KEYS.SERVER]: currentServerKey,
      [STORAGE_KEYS.STARTED_AT]: premium ? null : startedAt,
      [STORAGE_KEYS.PREMIUM_STATUS]: premium
    });

    if (premium) {
      clearAutoDisable();
    } else {
      startAutoDisable(startedAt);
    }

    startSessionCheckAlarm();
    startStateSyncAlarm();

    chrome.notifications.create({
      type: "basic",
      iconUrl: "icon.png",
      title: "Sakura VPN",
      message: premium ? `🟢 Premium • ${getServerName(currentServerKey)}` : `⏱ Бесплатно • ${getServerName(currentServerKey)}`
    });

    await setVpnState("ON");
    notifyPopup({ type: "STATE_CHANGE", state: "ON", premium });

  } catch (error) {
    await setVpnState("ERROR");
    console.error("[QU] Enable failed:", error);
    
    await clearProxy().catch(() => {});
    await clearSession();
    await storageSet({ 
      [STORAGE_KEYS.ENABLED]: false, 
      [STORAGE_KEYS.STARTED_AT]: null 
    });

    let userMessage = "Не удалось подключиться";
    if (error.message.includes("Failed to fetch") || error.message.includes("Network")) {
      userMessage = "Сервер недоступен. Проверьте интернет-соединение";
    } else if (error.message.includes("rate_limit")) {
      userMessage = "Слишком много попыток подключения. Подождите немного";
    } else if (error.message.includes("no_nodes_available")) {
      userMessage = "Нет доступных серверов. Попробуйте другую страну";
    } else if (error.message.includes("no_ports_available")) {
      userMessage = "Сервер перегружен. Попробуйте позже";
    }

    chrome.notifications.create({
      type: "basic",
      iconUrl: "icon.png",
      title: "Sakura VPN - Ошибка",
      message: userMessage
    });

    notifyPopup({ type: "STATE_ERROR", error: userMessage });
    throw error;
  } finally {
    await clearOperationLock();
  }
}

async function doDisable(auto = false) {
  // NOTE: intentionally NOT checking isOperationInProgress() here.
  // Disconnect must always succeed regardless of any in-flight operation —
  // otherwise a stuck lock leaves the user without internet.
  await clearOperationLock();
  await setOperationLock("DISABLE");

  await setVpnState("DISABLING");
  notifyPopup({ type: "STATE_CHANGE", state: "DISABLING" });

  try {
    clearAutoDisable();
    stopSessionCheckAlarm();
    stopStateSyncAlarm();
    
    // Fire-and-forget destroy — не блокируем отключение ожиданием сервера.
    // Сессия умрёт по TTL даже если запрос не дойдёт.
    destroySession().catch((e) => {
      console.warn("[QU] destroySession failed (server unreachable?), continuing local cleanup:", e.message);
    });

    // Очищаем локально сразу параллельно
    await Promise.all([
      clearProxy(),
      clearSession()
    ]);

    await storageSet({ 
      [STORAGE_KEYS.ENABLED]: false, 
      [STORAGE_KEYS.STARTED_AT]: null 
    });

    chrome.notifications.create({
      type: "basic",
      iconUrl: "icon.png",
      title: "Sakura VPN",
      message: auto ? "⏰ Время вышло" : "🔴 VPN отключён"
    });

    await setVpnState("OFF");
    notifyPopup({ type: "STATE_CHANGE", state: "OFF" });

  } catch (error) {
    // Even if something above failed, force-clear the proxy as a last resort
    console.error("[QU] Disable failed, force-clearing proxy:", error);
    await clearProxy().catch(() => {});
    await storageSet({ 
      [STORAGE_KEYS.ENABLED]: false, 
      [STORAGE_KEYS.STARTED_AT]: null 
    }).catch(() => {});
    await setVpnState("OFF");
    notifyPopup({ type: "STATE_CHANGE", state: "OFF" });
  } finally {
    await clearOperationLock();
  }
}

async function doSwitchServer(newKey) {
  if (!getServerByKey(newKey)) return;

  if (await isOperationInProgress()) {
    console.log("[QU] Operation already in progress, skipping server switch");
    return;
  }

  await storageSet({ [STORAGE_KEYS.SERVER]: newKey });

  const state = await storageGet(STORAGE_KEYS.ENABLED);
  const enabled = state[STORAGE_KEYS.ENABLED];
  if (!enabled) return;

  await setOperationLock("SWITCH");
  await setVpnState("SWITCHING");
  notifyPopup({ type: "STATE_CHANGE", state: "SWITCHING" });

  try {
    const t0 = Date.now();

    clearAutoDisable();
    stopSessionCheckAlarm();
    stopStateSyncAlarm();

    // Fire-and-forget destroy — не ждём ответа сервера,
    // сессия всё равно умрёт по TTL
    destroySession().catch((e) => {
      console.warn("[QU] destroySession failed during switch:", e.message);
    });

    // Очищаем локально сразу, не дожидаясь сервера
    await Promise.all([
      clearProxy(),
      clearSession(),
      storageSet({ [STORAGE_KEYS.ENABLED]: false, [STORAGE_KEYS.STARTED_AT]: null })
    ]);

    await setVpnState("ENABLING");
    notifyPopup({ type: "STATE_CHANGE", state: "ENABLING" });

    // Параллельно: premium + новая сессия
    const [{ premium }, session] = await Promise.all([
      fetchPremiumStatus(false),
      createSession(newKey)
    ]);

    console.log(`[QU] ⏱ doSwitchServer total: ${Date.now() - t0}ms`);

    await setProxy(session.proxy.host, session.proxy.port);

    const startedAt = Date.now();
    await storageSet({
      [STORAGE_KEYS.ENABLED]: true,
      [STORAGE_KEYS.SERVER]: newKey,
      [STORAGE_KEYS.STARTED_AT]: premium ? null : startedAt,
      [STORAGE_KEYS.PREMIUM_STATUS]: premium
    });

    if (premium) {
      clearAutoDisable();
    } else {
      startAutoDisable(startedAt);
    }

    startSessionCheckAlarm();
    startStateSyncAlarm();
    await setVpnState("ON");
    notifyPopup({ type: "STATE_CHANGE", state: "ON", premium, switched: true });

  } catch (error) {
    await setVpnState("ERROR");
    console.error("[QU] Switch server failed:", error);
    notifyPopup({ type: "STATE_ERROR", error: error.message });
  } finally {
    await clearOperationLock();
  }
}

// ========= ВОССТАНОВЛЕНИЕ СОСТОЯНИЯ =========

/**
 * КРИТИЧЕСКАЯ ФУНКЦИЯ: Восстанавливает состояние VPN
 * Вызывается при каждом пробуждении service worker
 */
async function restoreState() {
  console.log("[QU] 🔄 Restoring state...");
  
  const state = await storageGet([
    STORAGE_KEYS.ENABLED,
    STORAGE_KEYS.SESSION,
    STORAGE_KEYS.SERVER,
    STORAGE_KEYS.STARTED_AT,
    STORAGE_KEYS.PREMIUM_STATUS,
    STORAGE_KEYS.VPN_STATE
  ]);
  
  const shouldBeEnabled = state[STORAGE_KEYS.ENABLED] === true;
  const session = state[STORAGE_KEYS.SESSION];
  const serverKey = state[STORAGE_KEYS.SERVER] || "de";
  const vpnState = state[STORAGE_KEYS.VPN_STATE] || "OFF";
  const proxyActive = await isProxyActuallyActive();
  
  console.log(`[QU] State: enabled=${shouldBeEnabled}, hasSession=${!!session}, vpnState=${vpnState}, proxyActive=${proxyActive}`);
  
  if (!shouldBeEnabled) {
    // VPN должен быть выключен
    if (proxyActive) {
      console.warn("[QU] Proxy is active but VPN should be OFF. Clearing...");
      await clearProxy();
    }
    await setVpnState("OFF");
    return;
  }
  
  // VPN должен быть включен
  if (!session) {
    console.error("[QU] ⚠️ VPN enabled but no session found. Force disable...");
    await doDisable(false);
    return;
  }
  
  // Проверяем, не истёк ли таймер для бесплатных пользователей
  if (state[STORAGE_KEYS.STARTED_AT] && !state[STORAGE_KEYS.PREMIUM_STATUS]) {
    const timeLeft = CONFIG.AUTO_DISABLE_MS - (Date.now() - state[STORAGE_KEYS.STARTED_AT]);
    if (timeLeft <= 0) {
      console.log("[QU] Free timer expired, disabling VPN");
      await doDisable(true);
      return;
    }
    // Восстанавливаем alarm
    startAutoDisable(state[STORAGE_KEYS.STARTED_AT]);
  }
  
  // Восстанавливаем прокси если он не активен
  if (!proxyActive) {
    console.log("[QU] Restoring proxy connection...");
    try {
      await setProxy(session.proxy.host, session.proxy.port);
      console.log("[QU] ✅ Proxy restored");
    } catch (error) {
      console.error("[QU] Failed to restore proxy:", error);
      await doDisable(false);
      return;
    }
  }
  
  // Восстанавливаем alarms
  startSessionCheckAlarm();
  startStateSyncAlarm();
  
  await setVpnState("ON");
  console.log("[QU] ✅ State restored successfully");
}

// ========= STARTUP & INSTALL HANDLERS =========

chrome.runtime.onStartup.addListener(async () => {
  console.log("[QU] 🚀 Browser started");
  await getOrCreateInstallId();
  
  // Всегда отключаем VPN при старте браузера
  console.log("[QU] Disabling VPN on browser startup");
  await storageSet({ [STORAGE_KEYS.ENABLED]: false });
  await clearProxy();
  await setVpnState("OFF");
  stopSessionCheckAlarm();
  stopStateSyncAlarm();
  clearAutoDisable();
});

chrome.runtime.onInstalled.addListener(async (details) => {
  console.log("[QU] Extension installed/updated:", details.reason);
  
  await getOrCreateInstallId();
  
  if (details.reason === "install") {
    console.log("[QU] First install - initializing defaults");
    await storageSet({
      [STORAGE_KEYS.SERVER]: "de",
      [STORAGE_KEYS.ENABLED]: false,
      [STORAGE_KEYS.VPN_STATE]: "OFF"
    });
  }
  
  // Восстанавливаем состояние после обновления
  if (details.reason === "update") {
    console.log("[QU] Extension updated - restoring state");
    await restoreState();
  }
});

// ========= ALARM HANDLERS =========

chrome.alarms.onAlarm.addListener(async (alarm) => {
  console.log(`[QU] Alarm fired: ${alarm.name}`);
  
  if (alarm.name === CONFIG.AUTO_DISABLE_ALARM) {
    const state = await storageGet([STORAGE_KEYS.ENABLED, STORAGE_KEYS.PREMIUM_STATUS]);
    // BUGFIX: Always check premium status here — this is the last line of defense.
    // Even if the alarm was incorrectly set (e.g. race condition during premium activation),
    // we must never disconnect a premium user.
    if (state[STORAGE_KEYS.ENABLED] && !state[STORAGE_KEYS.PREMIUM_STATUS]) {
      console.log("[QU] Auto-disable timer fired (free user)");
      await doDisable(true);
    } else if (state[STORAGE_KEYS.PREMIUM_STATUS]) {
      console.warn("[QU] Auto-disable alarm fired for premium user — ignoring and clearing alarm");
      clearAutoDisable();
    }
    return;
  }
  
  if (alarm.name === CONFIG.SESSION_CHECK_ALARM) {
    const state = await storageGet([STORAGE_KEYS.ENABLED, STORAGE_KEYS.SESSION]);
    if (state[STORAGE_KEYS.ENABLED] && state[STORAGE_KEYS.SESSION]) {
      const session = state[STORAGE_KEYS.SESSION];
      if (isSessionExpiringSoon(session)) {
        console.log("[QU] Session expiring soon, refreshing...");
        try {
          await refreshSession();
        } catch (error) {
          console.error("[QU] Session refresh failed:", error.message);
        }
      } else {
        console.log("[QU] Session check alarm fired — session still valid, skipping refresh");
      }
    }
    return;
  }
  
  if (alarm.name === CONFIG.STATE_SYNC_ALARM) {
    await checkStateSync();
    return;
  }
});

// ========= MESSAGES =========
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    if (msg === "VPN_ENABLE") {
      const state = await storageGet(STORAGE_KEYS.ENABLED);
      if (!state[STORAGE_KEYS.ENABLED]) {
        await doEnable();
      }
      sendResponse({ ok: true });
      return;
    }

    if (msg === "VPN_DISABLE") {
      const state = await storageGet(STORAGE_KEYS.ENABLED);
      if (state[STORAGE_KEYS.ENABLED]) {
        await doDisable(false);
      }
      sendResponse({ ok: true });
      return;
    }

    if (msg?.type === "SET_SERVER" && SERVERS[msg.server]) {
      await doSwitchServer(msg.server);
      sendResponse({ ok: true });
      return;
    }

    if (msg?.type === "GET_INSTALL_ID") {
      const id = await getOrCreateInstallId();
      sendResponse({ ok: true, install_id: id });
      return;
    }

    if (msg?.type === "CHECK_PREMIUM") {
      const s = await fetchPremiumStatus(true);
      if (s.premium) {
        clearAutoDisable();
        await storageSet({ 
          [STORAGE_KEYS.STARTED_AT]: null, 
          [STORAGE_KEYS.PREMIUM_STATUS]: true 
        });
      }
      sendResponse({ ok: true, ...s });
      return;
    }

    if (msg?.type === "GET_STATE") {
      const state = await storageGet([
        STORAGE_KEYS.ENABLED,
        STORAGE_KEYS.SERVER,
        STORAGE_KEYS.STARTED_AT,
        STORAGE_KEYS.PREMIUM_STATUS,
        STORAGE_KEYS.VPN_STATE
      ]);
      sendResponse({ 
        ok: true, 
        enabled: state[STORAGE_KEYS.ENABLED],
        server: state[STORAGE_KEYS.SERVER],
        vpnStartedAt: state[STORAGE_KEYS.STARTED_AT],
        premiumStatus: state[STORAGE_KEYS.PREMIUM_STATUS],
        vpnState: state[STORAGE_KEYS.VPN_STATE]
      });
      return;
    }

    sendResponse({ ok: false, error: "unknown_message" });
  })();

  return true;
});

// ========= INITIALIZATION =========
async function initialize() {
  console.log("[QU] ========================================");
  console.log("[QU] Initializing v3.0 (Service Worker Resilient)");
  console.log("[QU] Security: Port = Session (no per-request tokens)");
  console.log("[QU] Migration: Enabled (seamless port rotation every 6h)");
  console.log("[QU] Resilience: State restored from storage after sleep");
  console.log("[QU] ========================================");
  
  await getOrCreateInstallId();
  await restoreState();
  
  console.log("[QU] ✅ Initialization complete");
}

// Запускаем инициализацию при загрузке service worker
initialize();